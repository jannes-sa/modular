package main

import (
	"tmod"
	_ "tmod2"
	_ "tmod3"
)

func main() {
	tmod.Run()
}
